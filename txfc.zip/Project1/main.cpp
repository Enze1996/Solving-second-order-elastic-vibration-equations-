﻿//火箭弹性振动方程是一个二阶常微分方程（ODE）：𝑞¨+2𝜁𝜔𝑞˙+𝜔^2𝑞=𝐶

#include <iostream>
#include <vector>

using namespace std;

struct State {
    double x1;  // q (广义坐标)
    double x2;  // q_dot (广义速度)
};

// 系统的右侧方程
State system(double t, const State& state, double omega, double zeta, double C) {
    State dxdt;
    dxdt.x1 = state.x2;
    dxdt.x2 = -2.0 * zeta * omega * state.x2 - omega * omega * state.x1 + C;
    return dxdt;
}

// 四阶Runge-Kutta积分方法
State rk4_step(double t, const State& state, double dt, double omega, double zeta, double C) {
    State k1 = system(t, state, omega, zeta, C);
    State k2 = system(t + 0.5 * dt, { state.x1 + 0.5 * k1.x1 * dt, state.x2 + 0.5 * k1.x2 * dt }, omega, zeta, C);
    State k3 = system(t + 0.5 * dt, { state.x1 + 0.5 * k2.x1 * dt, state.x2 + 0.5 * k2.x2 * dt }, omega, zeta, C);
    State k4 = system(t + dt, { state.x1 + k3.x1 * dt, state.x2 + k3.x2 * dt }, omega, zeta, C);

    State nextState;
    nextState.x1 = state.x1 + (dt / 6.0) * (k1.x1 + 2.0 * (k2.x1 + k3.x1) + k4.x1);
    nextState.x2 = state.x2 + (dt / 6.0) * (k1.x2 + 2.0 * (k2.x2 + k3.x2) + k4.x2);

    return nextState;
}

int main() {
    double omega = 1.0;  // 自然频率
    double zeta = 0.05;  // 阻尼比
    double C = 1.0;      // 常数C
    double dt = 0.01;    // 时间步长
    double t_end = 10.0; // 仿真结束时间

    State state = { 0.0, 0.0 };  // 初始状态 q = 0, q_dot = 0
    double t = 0.0;

    // 时间循环
    while (t < t_end) {
        cout << "Time: " << t << " | q: " << state.x1 << " | q_dot: " << state.x2 << endl;
        state = rk4_step(t, state, dt, omega, zeta, C);  // RK4一步
        t += dt;
    }

    return 0;
}
